# SHEKHAR Bhardwaj Vlogs — Animated livestream overlay

A single-file, transparent, animated 1920×1080 overlay. No paid assets or external libraries.

## GitHub Pages (phone or PC)
1. Create a **public** GitHub repository, e.g. `shekhar-overlay`.
2. Upload `index.html` to the repository root, then commit.
3. Go to **Settings → Pages → Build and deployment → Deploy from a branch**, choose `main` and `/ (root)`, then Save.
4. After deployment, open `https://YOUR-USERNAME.github.io/shekhar-overlay/`.
5. In OBS/PRISM Live, add a **Browser Source / Web source** with this URL, width **1920**, height **1080**. Position it **above gameplay**.
6. Add the camera source **under the overlay** and position/resize it behind the upper-left transparent facecam frame. Do not use a black background behind the overlay.

## Personalize using URL
- `?channel=SHEKHAR&subtitle=Bhardwaj%20Vlogs&subs=2781`
- `?facecam=off` hides the facecam border.
- `?ball=off` hides the two 8-ball graphics.

Example: `https://YOUR-USERNAME.github.io/shekhar-overlay/?subs=3000`

## Important
- The subscriber count is a manually set display value, **not an automatic live YouTube subscriber counter**.
- The LIVE indicator is a graphic, not a YouTube connection.
- The overlay is transparent in OBS/PRISM Browser Source. Some ordinary browser previews may appear black because of the viewer background.
- Mobile streaming apps must support a Browser/Web source or URL overlay; not every app supports this.
- For correct positioning use a **16:9 canvas** (ideally 1920×1080).
